package com.example.JsonDataset.Tests;

import com.example.JsonDataset.Repository.DatasetRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class DatasetControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    private final String datasetName = "users";
    
    @Autowired
    private DatasetRepository datasetRepository;
    @BeforeEach
    void cleanDatabase() {
        datasetRepository.deleteAll();
    }

    @BeforeEach
    void setup() throws Exception {
        // Insert two records before each test
        mockMvc.perform(post("/api/dataset/" + datasetName + "/record")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"Alice\",\"age\":25,\"city\":\"Chennai\"}"))
                .andExpect(status().isOk());

        mockMvc.perform(post("/api/dataset/" + datasetName + "/record")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"Bob\",\"age\":30,\"city\":\"Delhi\"}"))
                .andExpect(status().isOk());
    }

    // ✅ Insert record successfully
    @Test
    void testInsertRecordSuccess() throws Exception {
        mockMvc.perform(post("/api/dataset/" + datasetName + "/record")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"Charlie\",\"age\":28,\"city\":\"Mumbai\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Record added successfully"))
                .andExpect(jsonPath("$.dataset").value(datasetName));
    }

    // ❌ Insert empty JSON
    @Test
    void testInsertEmptyJson() throws Exception {
        mockMvc.perform(post("/api/dataset/" + datasetName + "/record")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("Validation failed"))
                .andExpect(jsonPath("$.details").value("Empty JSON data not allowed"));
    }

    // ❌ Insert malformed JSON
    @Test
    void testInsertMalformedJson() throws Exception {
        mockMvc.perform(post("/api/dataset/" + datasetName + "/record")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{name:Alice}")) // ❌ no quotes
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("Malformed JSON request"));
    }

    // ✅ Bulk insert
    @Test
    void testBulkInsertSuccess() throws Exception {
        String bulkJson = "[{\"name\":\"David\",\"age\":22},{\"name\":\"Eve\",\"age\":35}]";
        mockMvc.perform(post("/api/dataset/" + datasetName + "/record")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(bulkJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("2 records added successfully"))
                .andExpect(jsonPath("$.dataset").value(datasetName));
    }

    // ❌ Bulk insert empty array
    @Test
    void testBulkInsertEmptyArray() throws Exception {
        mockMvc.perform(post("/api/dataset/" + datasetName + "/record")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("[]"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("Validation failed"))
                .andExpect(jsonPath("$.details").value("Bulk insert request cannot be an empty array"));
    }

    // ✅ Query with sortBy ASC
    @Test
    void testSortByAsc() throws Exception {
        mockMvc.perform(get("/api/dataset/" + datasetName + "/query")
                        .param("sortBy", "age")
                        .param("order", "asc"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.sortedRecords[0].name").value("Alice"))
                .andExpect(jsonPath("$.sortedRecords[1].name").value("Bob"));
    }

    // ✅ Query with sortBy DESC
    @Test
    void testSortByDesc() throws Exception {
        mockMvc.perform(get("/api/dataset/" + datasetName + "/query")
                        .param("sortBy", "age")
                        .param("order", "desc"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.sortedRecords[0].name").value("Bob"))
                .andExpect(jsonPath("$.sortedRecords[1].name").value("Alice"));
    }

    // ❌ Invalid order
    @Test
    void testInvalidOrderValue() throws Exception {
        mockMvc.perform(get("/api/dataset/" + datasetName + "/query")
                        .param("sortBy", "age")
                        .param("order", "xyz"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.details").value("Invalid order value. Use 'asc' or 'desc'."));
    }

    // ✅ Group by city
    @Test
    void testGroupByCity() throws Exception {
        mockMvc.perform(get("/api/dataset/" + datasetName + "/query")
                        .param("groupBy", "city"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.groupedRecords.Chennai[0].name").value("Alice"))
                .andExpect(jsonPath("$.groupedRecords.Delhi[0].name").value("Bob"));
    }

    // ❌ Group by missing field
    @Test
    void testGroupByInvalidField() throws Exception {
        mockMvc.perform(get("/api/dataset/" + datasetName + "/query")
                        .param("groupBy", "invalidField"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.details").value("Field 'invalidField' not found in dataset: " + datasetName));
    }
    
    @Test
    void testQueryNoParameters() throws Exception {
        mockMvc.perform(get("/api/dataset/" + datasetName + "/query"))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("Please provide either groupBy or sortBy parameter"));
    }
    
 // ❌ Insert invalid JSON type (not Map or List)
    @Test
    void testInsertInvalidJsonType() throws Exception {
        mockMvc.perform(post("/api/dataset/" + datasetName + "/record")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("\"Just a string\"")) // JSON string, not object or array
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("Validation failed"))
                .andExpect(jsonPath("$.details").value("Invalid request body. Must be a JSON object or an array of JSON objects."));
    }

}
