package com.example.JsonDataset.Tests;

import com.example.JsonDataset.Entity.DatasetRecord;
import com.example.JsonDataset.Repository.DatasetRepository;
import com.example.JsonDataset.Service.DataService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class DataServiceTest {

    private DataService dataService;
    private DatasetRepository repositoryMock;
    private ObjectMapper objectMapper;
    private final String datasetName = "users";

    @BeforeEach
    void setup() throws Exception {
    	
    	    repositoryMock = Mockito.mock(DatasetRepository.class);
    	    objectMapper = new ObjectMapper();
    	    dataService = new DataService(repositoryMock,objectMapper);
    	


        
        when(repositoryMock.save(any(DatasetRecord.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

       
        dataService.insertRecord(datasetName, Map.of("name", "Alice", "age", 25, "city", "Chennai"));
        dataService.insertRecord(datasetName, Map.of("name", "Bob", "age", 30, "city", "Delhi"));
    }

    // Single record insert
    @Test
    void testInsertRecordSuccess() throws Exception {
        Map<String, Object> record = Map.of("name", "Charlie", "age", 28, "city", "Mumbai");
        DatasetRecord saved = dataService.insertRecord(datasetName, record);

        Map<String, Object> parsed = dataService.parseJson(saved.getJsonData());
        assertEquals("Charlie", parsed.get("name"));
        assertEquals(28, parsed.get("age"));
        assertEquals("Mumbai", parsed.get("city"));
    }

    //Empty record
    @Test
    void testInsertEmptyRecord() {
        assertThrows(IllegalArgumentException.class,
                () -> dataService.insertRecord(datasetName, Collections.emptyMap()));
    }

    //Bulk insert
    @Test
    void testInsertMultipleRecords() throws Exception {
        List<Map<String, Object>> records = List.of(
                Map.of("name", "David", "age", 22, "city", "Pune"),
                Map.of("name", "Eve", "age", 35, "city", "Chennai")
        );

        List<DatasetRecord> saved = dataService.insertMultipleRecords(datasetName, records);
        assertEquals(2, saved.size());

        Map<String, Object> parsed1 = dataService.parseJson(saved.get(0).getJsonData());
        Map<String, Object> parsed2 = dataService.parseJson(saved.get(1).getJsonData());

        assertEquals("David", parsed1.get("name"));
        assertEquals("Eve", parsed2.get("name"));
    }

    //Bulk insert empty list
    @Test
    void testInsertMultipleEmptyList() {
        assertThrows(IllegalArgumentException.class,
                () -> dataService.insertMultipleRecords(datasetName, Collections.emptyList()));
    }

    //Sort ascending
    @Test
    void testSortByAsc() throws Exception {
        List<DatasetRecord> records = List.of(
                createRecord("Alice", 25, "Chennai"),
                createRecord("Bob", 30, "Delhi")
        );
        when(repositoryMock.findByDatasetName(datasetName)).thenReturn(records);

        List<Map<String, Object>> sorted = dataService.sortBy(datasetName, "age", "asc");
        assertEquals("Alice", sorted.get(0).get("name"));
        assertEquals("Bob", sorted.get(1).get("name"));
    }

    //Sort descending
    @Test
    void testSortByDesc() throws Exception {
        List<DatasetRecord> records = List.of(
                createRecord("Alice", 25, "Chennai"),
                createRecord("Bob", 30, "Delhi")
        );
        when(repositoryMock.findByDatasetName(datasetName)).thenReturn(records);

        List<Map<String, Object>> sorted = dataService.sortBy(datasetName, "age", "desc");
        assertEquals("Bob", sorted.get(0).get("name"));
        assertEquals("Alice", sorted.get(1).get("name"));
    }

    //Invalid order
    @Test
    void testSortInvalidOrder() {
        assertThrows(IllegalArgumentException.class,
                () -> dataService.sortBy(datasetName, "age", "wrong"));
    }

    //Sort by missing field
    @Test
    void testSortByMissingField() {
        assertThrows(IllegalArgumentException.class,
                () -> dataService.sortBy(datasetName, "salary", "asc"));
    }

    //Group by city
    @Test
    void testGroupByCity() throws Exception {
        List<DatasetRecord> records = List.of(
                createRecord("Alice", 25, "Chennai"),
                createRecord("Bob", 30, "Delhi"),
                createRecord("Charlie", 28, "Chennai")
        );
        when(repositoryMock.findByDatasetName(datasetName)).thenReturn(records);

        Map<String, List<Map<String, Object>>> grouped = dataService.groupBy(datasetName, "city");
        assertTrue(grouped.containsKey("Chennai"));
        assertTrue(grouped.containsKey("Delhi"));
        assertEquals(2, grouped.get("Chennai").size());
        assertEquals(1, grouped.get("Delhi").size());
    }

    //Group by invalid field
    @Test
    void testGroupByInvalidField() {
        assertThrows(IllegalArgumentException.class,
                () -> dataService.groupBy(datasetName, "invalidField"));
    }
    
    //Sort by mixed types
    @Test
    void testSortByMixedTypes() {
        String dataset = "mixedDataset";

        List<DatasetRecord> records = List.of(
            new DatasetRecord(null, dataset, "{\"name\":\"Alice\",\"age\":25}"),
            new DatasetRecord(null, dataset, "{\"name\":\"Bob\",\"age\":\"30\"}") // age as String
        );

        Mockito.when(repositoryMock.findByDatasetName(dataset)).thenReturn(records);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            dataService.sortBy(dataset, "age", "asc");
        });

        assertTrue(exception.getMessage().contains("has mixed types"));
    }
    
    //sort by noncomparable fields
    @Test
    void testSortByNonComparableField() {
        String dataset = "nonComparable";

        List<DatasetRecord> records = List.of(
            new DatasetRecord(null, dataset, "{\"name\":\"Alice\",\"details\":{\"city\":\"NY\"}}"),
            new DatasetRecord(null, dataset, "{\"name\":\"Bob\",\"details\":{\"city\":\"LA\"}}")
        );

        Mockito.when(repositoryMock.findByDatasetName(dataset)).thenReturn(records);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            dataService.sortBy(dataset, "details", "asc");
        });

        assertTrue(exception.getMessage().contains("is not comparable"));
    }

    
    //Helper method to create DatasetRecord
    private DatasetRecord createRecord(String name, int age, String city) throws Exception {
        Map<String, Object> record = Map.of("name", name, "age", age, "city", city);
        DatasetRecord datasetRecord = new DatasetRecord();
        datasetRecord.setDatasetName(datasetName);
        datasetRecord.setJsonData(objectMapper.writeValueAsString(record));
        return datasetRecord;
    }
    
    
}
