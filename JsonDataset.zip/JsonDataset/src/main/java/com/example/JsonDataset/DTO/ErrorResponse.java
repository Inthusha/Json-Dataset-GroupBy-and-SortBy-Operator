package com.example.JsonDataset.DTO;

import java.time.LocalDateTime;

public class ErrorResponse 
{
	
	private String message;
	private String details;
	private LocalDateTime timestamp;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	public LocalDateTime getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}
	public ErrorResponse(String message, String details) {
		super();
		this.message = message;
		this.details = details;
		this.timestamp = LocalDateTime.now();
	}
	public ErrorResponse() {
		super();
	}
	@Override
	public String toString() {
		return "ErrorResponse [message=" + message + ", details=" + details + ", timestamp=" + timestamp + "]";
	}
	
	
	
	
	

}
