package com.example.JsonDataset;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonDatasetApplication {

	public static void main(String[] args) {
		SpringApplication.run(JsonDatasetApplication.class, args);
	}

}
