package com.example.JsonDataset.DTO;

import java.util.List;
import java.util.Map;

public class GroupByResponse {
	
	private Map<String,List<Map<String,Object>>>groupedRecords;

	public Map<String, List<Map<String, Object>>> getGroupedRecords() {
		return groupedRecords;
	}

	public void setGroupedRecords(Map<String, List<Map<String, Object>>> groupedRecords) {
		this.groupedRecords = groupedRecords;
	}

	public GroupByResponse(Map<String, List<Map<String, Object>>> groupedRecords) {
		super();
		this.groupedRecords = groupedRecords;
	}

	public GroupByResponse() {
		super();
	}

	@Override
	public String toString() {
		return "GroupByResponse [groupedRecords=" + groupedRecords + "]";
	}
	
	

}
