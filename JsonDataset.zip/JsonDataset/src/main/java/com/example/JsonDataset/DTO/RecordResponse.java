package com.example.JsonDataset.DTO;

public class RecordResponse 
{
	
	private String message;
	private String dataset;
	private Long recordId;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDataset() {
		return dataset;
	}
	public void setDataset(String dataset) {
		this.dataset = dataset;
	}
	public Long getRecordId() {
		return recordId;
	}
	public void setRecordId(Long recordId) {
		this.recordId = recordId;
	}
	@Override
	public String toString() {
		return "RecordResponse [message=" + message + ", dataset=" + dataset + ", recordId=" + recordId + "]";
	}
	public RecordResponse(String message, String dataset, Long recordId) {
		super();
		this.message = message;
		this.dataset = dataset;
		this.recordId = recordId;
	}
	public RecordResponse() {
		super();
	}
	
	
	
	
}
