package com.example.JsonDataset.Service;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.JsonDataset.Entity.DatasetRecord;
import com.example.JsonDataset.Repository.DatasetRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class DataService 
{
	 private final DatasetRepository repository;
	    private final ObjectMapper objectMapper;

	    @Autowired
	    public DataService(DatasetRepository repository, ObjectMapper objectMapper) {
	        this.repository = repository;
	        this.objectMapper = objectMapper;
	    }
	
	

	public DatasetRecord insertRecord(String datasetName,Map<String,Object>record)throws Exception
	{
		 if (record == null || record.isEmpty()) {
		        throw new IllegalArgumentException("Empty JSON data not allowed");
		    }
		String jsonString=objectMapper.writeValueAsString(record);
		DatasetRecord datasetRecord = new DatasetRecord();
		datasetRecord.setDatasetName(datasetName);
		datasetRecord.setJsonData(jsonString);
        return repository.save(datasetRecord);
		
	}
	
	public List<DatasetRecord> insertMultipleRecords(String datasetName, List<Map<String, Object>> records) throws Exception {
		 if (records == null || records.isEmpty()) {
		        throw new IllegalArgumentException("Empty JSON data not allowed");
		    }
	    List<DatasetRecord> savedRecords = new ArrayList<>();

	    for (Map<String, Object> record : records) {
	        if (record == null || record.isEmpty()) {
	            throw new IllegalArgumentException("Empty JSON object is not allowed in bulk insert");
	        }

	        String jsonString = objectMapper.writeValueAsString(record);
	        DatasetRecord datasetRecord = new DatasetRecord();
	        datasetRecord.setDatasetName(datasetName);
	        datasetRecord.setJsonData(jsonString);

	        savedRecords.add(repository.save(datasetRecord));
	    }

	    return savedRecords;
	}

	
	
	public Map<String,List<Map<String,Object>>> groupBy(String datasetName,String field)
	{
		
		List<DatasetRecord>records=repository.findByDatasetName(datasetName);
		 if (records.isEmpty()) {
		        throw new IllegalArgumentException("No records found for dataset: " + datasetName);
		    }
		 
		    List<Map<String, Object>> parsed = records.stream()
		            .map(r -> parseJson(r.getJsonData()))
		            .toList();

		    boolean fieldExists = parsed.stream().anyMatch(map -> map.containsKey(field));
		    if (!fieldExists) {
		        throw new IllegalArgumentException("Field '" + field + "' not found in dataset: " + datasetName);
		    }

		    return parsed.stream()
		            .collect(Collectors.groupingBy(record -> String.valueOf(record.get(field))));

		
		
	}
	
	public List<Map<String,Object>>sortBy(String datasetName,String field,String order)
	{
		List<DatasetRecord>records=repository.findByDatasetName(datasetName);
		 if (records.isEmpty()) {
		        throw new IllegalArgumentException("No records found for dataset: " + datasetName);
		    }
		 if (order != null && !order.equalsIgnoreCase("asc") && !order.equalsIgnoreCase("desc")) {
		        throw new IllegalArgumentException("Invalid order value. Use 'asc' or 'desc'.");
		    }
		 List<Map<String, Object>> parsed = records.stream()
		            .map(r -> parseJson(r.getJsonData()))
		            .toList();

		    boolean fieldExists = parsed.stream().anyMatch(map -> map.containsKey(field));
		    if (!fieldExists) {
		        throw new IllegalArgumentException("Field '" + field + "' not found in dataset: " + datasetName);
		    }

		    return parsed.stream()
		            .sorted((map1, map2) -> {
		                Object v1 = map1.get(field);
		                Object v2 = map2.get(field);

		                if (!(v1 instanceof Comparable) || !(v2 instanceof Comparable)) {
		                    throw new IllegalArgumentException("Field '" + field + "' is not comparable");
		                }
		                
		                if (v1 != null && v2 != null && !v1.getClass().equals(v2.getClass())) {
		                    throw new IllegalArgumentException("Field '" + field + "' has mixed types: "
		                            + v1.getClass().getSimpleName() + " and " + v2.getClass().getSimpleName());
		                }


		                Comparable c1 = (Comparable) v1;
		                Comparable c2 = (Comparable) v2;

		                return "desc".equalsIgnoreCase(order) ? c2.compareTo(c1) : c1.compareTo(c2);
		            })
		            .toList();

	}
	
	public Map<String,Object>parseJson(String json)
	{
		try {
			return objectMapper.readValue(json, new TypeReference<Map<String,Object>>() {});
		}
		catch(Exception e)
		{
			throw new RuntimeException("Failed to parse jsonData",e);
		}
	}
	

}
