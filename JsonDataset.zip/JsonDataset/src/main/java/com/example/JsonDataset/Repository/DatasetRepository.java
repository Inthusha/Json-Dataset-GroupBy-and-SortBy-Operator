package com.example.JsonDataset.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.JsonDataset.Entity.DatasetRecord;

public interface DatasetRepository extends JpaRepository<DatasetRecord,Long> {

	List<DatasetRecord>findByDatasetName(String datasetName);
}
