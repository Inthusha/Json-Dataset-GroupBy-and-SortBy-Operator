package com.example.JsonDataset.Exception;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ExceptionHandler;

import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.example.JsonDataset.DTO.ErrorResponse;

@RestControllerAdvice
public class GlobalExceptionHandler 
{
	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<ErrorResponse>handleIllgalArgument(IllegalArgumentException ex)
	{
		ErrorResponse error=new ErrorResponse("Validation failed",ex.getMessage());
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
	}
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponse>handleGeneric(Exception ex)
	{
		ErrorResponse error=new ErrorResponse("Server error",ex.getMessage());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
	}
	
	@ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ErrorResponse> handleInvalidJson(HttpMessageNotReadableException ex) 
	{
        ErrorResponse error = new ErrorResponse("Malformed JSON request", ex.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
    }
	

}
