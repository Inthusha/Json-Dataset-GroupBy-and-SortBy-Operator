package com.example.JsonDataset.Controller;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.JsonDataset.DTO.GroupByResponse;
import com.example.JsonDataset.DTO.RecordResponse;
import com.example.JsonDataset.DTO.SortedResponse;
import com.example.JsonDataset.Entity.DatasetRecord;
import com.example.JsonDataset.Service.DataService;

@RestController
@RequestMapping("/api/dataset")
public class DatasetController 
{
	@Autowired
	private DataService dataService;
	
	@PostMapping("/{datasetName}/record")
	public ResponseEntity<?> insertRecord(@PathVariable String datasetName,@RequestBody Object requestBody) throws Exception
	{
		if (requestBody instanceof Map) 
		{
			Map<String, Object> record = (Map<String, Object>) requestBody;
		
		    DatasetRecord saved=dataService.insertRecord(datasetName, record);
		
		    RecordResponse response=new RecordResponse(
				"Record added successfully",
				datasetName,
				saved.getId());
		
		
		return ResponseEntity.ok(response);
		}
		
		else if (requestBody instanceof List) {
	        // Handle array of JSON objects
	        List<Map<String, Object>> records = (List<Map<String, Object>>) requestBody;
	        if (records.isEmpty()) {
	            throw new IllegalArgumentException("Bulk insert request cannot be an empty array");
	        }

	        List<DatasetRecord> savedRecords = dataService.insertMultipleRecords(datasetName, records);

	        return ResponseEntity.ok(Map.of(
	                "message", savedRecords.size() + " records added successfully",
	                "dataset", datasetName
	        ));

	    } else {
	        throw new IllegalArgumentException("Invalid request body. Must be a JSON object or an array of JSON objects.");
	    }
		
		
	}
	
	
	@GetMapping("/{datasetName}/query")
	public ResponseEntity<?>query(@PathVariable String datasetName,@RequestParam(required = false) String groupBy,@RequestParam(required = false) String sortBy,@RequestParam(required = false) String order)
	{
		
		if(groupBy!=null)
		{
		  Map<String,List<Map<String,Object>>>result=dataService.groupBy(datasetName, groupBy);
		  return ResponseEntity.ok(new GroupByResponse(result));
		}
		else if(sortBy!=null)
		{
			List<Map<String,Object>>result=dataService.sortBy(datasetName,sortBy,order);
			return ResponseEntity.ok(new SortedResponse(result));
		}
		else {
			return ResponseEntity.badRequest()
	                .body("Please provide either groupBy or sortBy parameter");
		}
		
	}
	

}
