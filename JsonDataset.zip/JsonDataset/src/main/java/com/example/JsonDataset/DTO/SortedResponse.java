package com.example.JsonDataset.DTO;

import java.util.List;
import java.util.Map;

public class SortedResponse 
{
	
	private List<Map<String,Object>>sortedRecords;

	public List<Map<String, Object>> getSortedRecords() {
		return sortedRecords;
	}

	public void setSortedRecords(List<Map<String, Object>> sortedRecords) {
		this.sortedRecords = sortedRecords;
	}

	@Override
	public String toString() {
		return "SortedResponse [sortedRecords=" + sortedRecords + "]";
	}

	public SortedResponse(List<Map<String, Object>> sortedRecords) {
		super();
		this.sortedRecords = sortedRecords;
	}

	public SortedResponse() {
		super();
	}
	
	
	
	

}
